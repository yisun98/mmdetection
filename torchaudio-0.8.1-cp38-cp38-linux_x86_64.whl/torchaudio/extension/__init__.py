from .extension import (
    _init_extension,
)

_init_extension()

del _init_extension
